library(tidyverse)

iris %>% 
  ggplot(aes(Sepal.Length, Sepal.Width, 
             colour = Species, size = Petal.Length)) +
  geom_point(alpha = 0.5)
